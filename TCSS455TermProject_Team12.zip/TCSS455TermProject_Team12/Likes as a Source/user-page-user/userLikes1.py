#ML in Python
#Guessing gender based on facebook likes technique 1: user-page-user

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score
import xml.etree.ElementTree as ET
import itertools
import copy
import pickle
import sys
import codecs
import os
import argparse
from os.path import basename, exists, join, splitext
from sklearn.feature_extraction.text import CountVectorizer

#------------------------------------------------------------------------------------
# Here we are testing the model for gender using our saved model. 
#------------------------------------------------------------------------------------

with open('SavedModelGender.pkl.txt', 'rb') as f:
	answerDict_Likeid_gender = pickle.load(f)

df3 = pd.read_csv(sys.argv[1]+"/profile/profile.csv")
profileData = df3.loc[:,['userid', 'gender']]

df4 = pd.read_csv("/data/public-test-data/relation/relation.csv")
likeData2 = df4.loc[:,['userid', 'like_id']]


#dictionary to keep track of gender of each userid
dictionary5 = {}

for i in range(len(profileData)):
	dictionary5.update({df3.loc[i, 'userid'] : 0})

#create 2 dictionaries to keep track of the like ids male likes count, and female likes count of each userid
likeDictFemale2 = copy.deepcopy(dictionary5)
likeDictMale2 = copy.deepcopy(dictionary5)

for x in range(len(likeData2)):
	if df4.loc[x, 'like_id'] in answerDict_Likeid_gender:
		if(answerDict_Likeid_gender[df4.loc[x, 'like_id']]) == 1:
			
			likeDictFemale2[df4.loc[x, 'userid']] = likeDictFemale2[df4.loc[x, 'userid']] +1
		else:
			likeDictMale2[df4.loc[x, 'userid']] = likeDictMale2[df4.loc[x, 'userid']] +1

finalAnswerDict = copy.deepcopy(dictionary5)

for u in finalAnswerDict:

	if likeDictFemale2[u] >= likeDictMale2[u]:
		finalAnswerDict[u] = 'female'
		
	else:
		finalAnswerDict[u] = 'male'
		

#------------------------------------------------------------------------------------
# Here we are testing the model for Age using our saved model. 
#------------------------------------------------------------------------------------
with open('SavedModelAge.pkl.txt', 'rb') as f:
	answerDict_Likeid_age = pickle.load(f)


#dictionary to keep track of gender of each userid
dictionary6 = {}

for i in range(len(profileData)):
	dictionary6.update({df3.loc[i, 'userid'] : 0})

dictFirst = copy.deepcopy(dictionary6)
dictSecond = copy.deepcopy(dictionary6)
dictThird = copy.deepcopy(dictionary6)
dictFourth = copy.deepcopy(dictionary6)
#print(answerDict_Likeid_age)

for x in range(len(likeData2)):
	
	if( df4.loc[x, 'like_id'] in answerDict_Likeid_age):
		
		if answerDict_Likeid_age[df4.loc[x, 'like_id']] == 'xx-24':
			dictFirst[df4.loc[x, 'userid']] = dictFirst[df4.loc[x, 'userid']] +1
		elif answerDict_Likeid_age[df4.loc[x, 'like_id']] == '25-34':
			dictSecond[df4.loc[x, 'userid']] = dictSecond[df4.loc[x, 'userid']] +1
		elif answerDict_Likeid_age[df4.loc[x, 'like_id']] == '35-49':
			dictThird[df4.loc[x, 'userid']] = dictThird[df4.loc[x, 'userid']] +1
		elif answerDict_Likeid_age[df4.loc[x, 'like_id']] == '50-xx':
			dictFourth[df4.loc[x, 'userid']] = dictFourth[df4.loc[x, 'userid']] +1
		


finalAnswerDictAge = copy.deepcopy(dictionary6)
#print(dictFirst)
for f in finalAnswerDictAge:
	
	if dictFirst[f]> dictSecond[f] and dictFirst[f] > dictThird[f] and dictFirst[f] > dictFourth[f]:
		finalAnswerDictAge[f] = 'xx-24'
	elif dictSecond[f]> dictFirst[f] and dictSecond[f] > dictThird[f] and dictSecond[f] > dictFourth[f]:
		finalAnswerDictAge[f] = '25-34'
	elif dictThird[f]> dictFirst[f] and dictThird[f] > dictSecond[f] and dictThird[f] > dictFourth[f]:
		finalAnswerDictAge[f] = '35-49'
	elif dictFourth[f]> dictFirst[f] and dictFourth[f] > dictSecond[f] and dictFourth[f] > dictThird[f]:
		finalAnswerDictAge[f] = '50-xx'
	else:
		finalAnswerDictAge[f] = 'xx-24'	
	
#create xml files
#print(finalAnswerDictAge)
for ID in finalAnswerDict:
    filename = '%s.xml' % ID
    filepath = sys.argv[2] + filename
	
    data = ET.Element('user')
    data.set('id', ID)
    data.set('age_group', finalAnswerDictAge[ID])
    data.set('gender', finalAnswerDict[ID])
    data.set('extrovert', '3.49')
    data.set('neurotic', '2.73')
    data.set('agreeable', '3.58')
    data.set('conscientious', '3.45')
    data.set('open', '3.91')

    mydata = ET.tostring(data).decode()
    myoutput = open(filepath, 'w+')
    myoutput.write(mydata)
    myoutput.close()






