#Predicting age based on facebook likes technique 1: user-page-user

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score
import itertools
import copy
import pickle

#-----------------------------------------------------------------------------
# Import data of userIds and associated Ages and split the data
# into model dictionary (8000 users) and test dictionary (1500 users)
#-----------------------------------------------------------------------------

# Reading the data of unique userid and associated age
df = pd.read_csv("profile.csv")
userData = df.loc[:,['userid', 'age']]

#create unique set of user ids
uniqueUserList = []
for user in userData['userid']:
	uniqueUserList.append(user)	
unique_userids = set(uniqueUserList)

#dictionary to keep track of age of each userid
dictionary_userid_age = {}

for i in range(len(userData)):
	dictionary_userid_age.update({df.loc[i, 'userid'] : df.loc[i, 'age']})
for x in dictionary_userid_age:
	if int(dictionary_userid_age[x]) <= 24:
		dictionary_userid_age[x] = 'xx-24'
	elif int(dictionary_userid_age[x]) >= 25 and int(dictionary_userid_age[x]) <=34:
		dictionary_userid_age[x] = '25-34'
	elif int(dictionary_userid_age[x]) >= 35 and int(dictionary_userid_age[x]) <=49:
		dictionary_userid_age[x] = '35-49'
	elif int(dictionary_userid_age[x]) >= 50:
		dictionary_userid_age[x] = '50-xx'
modelDict = dict(list(dictionary_userid_age.items())[:9500])
testDict = dict(list(dictionary_userid_age.items())[8000:9500])



#------------------------------------------------------------------------------------
# Here we are testing the model. For each user in the model data, we will 
# figure out which pages they have liked and count how many of each age group
# liked a given page. The majority age group is what the like_id is classified as. 
#------------------------------------------------------------------------------------

df2 = pd.read_csv("relation.csv")
likeData = df2.loc[:,['userid', 'like_id']]

#create unique set of like ids
uniqueLikeidList = []
for likeid in likeData['like_id']:
	uniqueLikeidList.append(likeid)	
unique_like_ids = set(uniqueLikeidList)

#create 4 dictionaries to keep track of each age group count
likeDictFirst = dict.fromkeys(unique_like_ids, 0)
likeDictSecond = dict.fromkeys(unique_like_ids, 0)
likeDictThird = dict.fromkeys(unique_like_ids, 0)
likeDictFourth = dict.fromkeys(unique_like_ids, 0)

#Iterate through the data and append age group like counts to their appropriate dictionaries
#to the female dictionary
for x in range(len(likeData)):
	if df2.loc[x, 'userid'] in modelDict:
		if modelDict[df2.loc[x, 'userid']] == 'xx-24':
			likeDictFirst[df2.loc[x, 'like_id']] = likeDictFirst[df2.loc[x, 'like_id']] +1
		elif modelDict[df2.loc[x, 'userid']] == '25-34':
			likeDictSecond[df2.loc[x, 'like_id']] = likeDictSecond[df2.loc[x, 'like_id']] +1
		elif modelDict[df2.loc[x, 'userid']] == '35-49':
			likeDictThird[df2.loc[x, 'like_id']] = likeDictThird[df2.loc[x, 'like_id']] +1
		elif modelDict[df2.loc[x, 'userid']] == '50-xx':
			likeDictFourth[df2.loc[x, 'like_id']] = likeDictFourth[df2.loc[x, 'like_id']] +1

# create answer dictionary (Most likely age group to like a page)
answerDict_Likeid_age = dict.fromkeys(unique_like_ids, 'xx-24')
for f in answerDict_Likeid_age:
	if likeDictFirst[f]> likeDictSecond[f] and likeDictFirst[f] > likeDictThird[f] and likeDictFirst[f] > likeDictFourth[f]:
		answerDict_Likeid_age[f] = 'xx-24'
	elif likeDictSecond[f]> likeDictFirst[f] and likeDictSecond[f] > likeDictThird[f] and likeDictSecond[f] > likeDictFourth[f]:
		answerDict_Likeid_age[f] = '25-34'
	elif likeDictThird[f]> likeDictFirst[f] and likeDictThird[f] > likeDictSecond[f] and likeDictThird[f] > likeDictFourth[f]:
		answerDict_Likeid_age[f] = '35-49'
	elif likeDictFourth[f]> likeDictFirst[f] and likeDictFourth[f] > likeDictSecond[f] and likeDictFourth[f] > likeDictThird[f]:
		answerDict_Likeid_age[f] = '50-xx'
#	else:
#		answerDict_Likeid_age[f] = 'xx-24'
with open('SavedModelAge02.pkl.txt', 'wb') as f:
	pickle.dump(answerDict_Likeid_age, f)
#--------------------------------------------------------------------------
#Determine Age of user (test Model)
#--------------------------------------------------------------------------
dictFirst = testDict.fromkeys(testDict,0)
dictSecond = testDict.fromkeys(testDict,0)
dictThird = testDict.fromkeys(testDict,0)
dictFourth = testDict.fromkeys(testDict,0)
finalAnswerDict = testDict.fromkeys(testDict,0)

for x in range(len(likeData)):
	if( df2.loc[x, 'userid'] in testDict):
		if answerDict_Likeid_age[df2.loc[x, 'like_id']] == 'xx-24':
			dictFirst[df2.loc[x, 'userid']] = dictFirst[df2.loc[x, 'userid']] +1
		elif answerDict_Likeid_age[df2.loc[x, 'like_id']] == '25-34':
			dictSecond[df2.loc[x, 'userid']] = dictSecond[df2.loc[x, 'userid']] +1
		elif answerDict_Likeid_age[df2.loc[x, 'like_id']] == '35-49':
			dictThird[df2.loc[x, 'userid']] = dictThird[df2.loc[x, 'userid']] +1
		elif answerDict_Likeid_age[df2.loc[x, 'like_id']] == '50-xx':
			dictFourth[df2.loc[x, 'userid']] = dictFourth[df2.loc[x, 'userid']] +1
		else:
			dictFirst[df2.loc[x, 'userid']] = dictFirst[df2.loc[x, 'userid']] +1

for f in finalAnswerDict:
	if dictFirst[f]> dictSecond[f] and dictFirst[f] > dictThird[f] and dictFirst[f] > dictFourth[f]:
		finalAnswerDict[f] = 'xx-24'
	elif dictSecond[f]> dictFirst[f] and dictSecond[f] > dictThird[f] and dictSecond[f] > dictFourth[f]:
		finalAnswerDict[f] = '25-34'
	elif dictThird[f]> dictFirst[f] and dictThird[f] > dictSecond[f] and dictThird[f] > dictFourth[f]:
		finalAnswerDict[f] = '35-49'
	elif dictFourth[f]> dictFirst[f] and dictFourth[f] > dictSecond[f] and dictFourth[f] > dictThird[f]:
		finalAnswerDict[f] = '50-xx'
	else:
		finalAnswerDict[f] = 'xx-24'
print(finalAnswerDict)	
#---------------------------------------------------------------------------
#Determine the accuracy
#---------------------------------------------------------------------------
countCorrect = 0

for d in finalAnswerDict:
	if finalAnswerDict[d] == testDict[d]:
		countCorrect = countCorrect +1
print(countCorrect/len(testDict))
print(len(testDict))








