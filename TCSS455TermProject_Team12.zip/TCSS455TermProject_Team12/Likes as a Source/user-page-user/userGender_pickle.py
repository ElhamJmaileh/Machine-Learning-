#Predicting gender based on facebook likes technique 1: user-page-user

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score
import itertools
import copy
import pickle

#-----------------------------------------------------------------------------
# Import data of userIds and associated genders and split the data
# into model dictionary (8000 users) and test dictionary (1500 users)
#-----------------------------------------------------------------------------

# Reading the data of unique userid and associated gender
df = pd.read_csv("profile.csv")
userData = df.loc[:,['userid', 'gender']]

#create unique set of user ids
uniqueUserList = []
for user in userData['userid']:
	uniqueUserList.append(user)	
unique_userids = set(uniqueUserList)

#dictionary to keep track of gender of each userid
dictionary_userid_gender = {}

for i in range(len(userData)):
	dictionary_userid_gender.update({df.loc[i, 'userid'] : df.loc[i, 'gender']})

modelDict = dict(list(dictionary_userid_gender.items())[:9500])
testDict = dict(list(dictionary_userid_gender.items())[8000:9500])


#------------------------------------------------------------------------------------
# Here we are testing the model. For each user in the model data, we will 
# figure out which pages they have liked and count how many of each gender
# liked a given page. If majority of those who liked the given page are male, 
# the page will be given a male label. If majority of those who liked the page are
# female, the page will be given a female label. If nobody liked a given page from the
# given model data, we will automatically assign it to have a male label. 
#------------------------------------------------------------------------------------

df2 = pd.read_csv("relation.csv")
likeData = df2.loc[:,['userid', 'like_id']]

#create unique set of like ids
uniqueLikeidList = []
for likeid in likeData['like_id']:
	uniqueLikeidList.append(likeid)	
unique_like_ids = set(uniqueLikeidList)

#create 2 dictionaries to keep track of the like ids male likes count, and female likes count
likeDictFemale = dict.fromkeys(unique_like_ids, 0)
likeDictMale = dict.fromkeys(unique_like_ids, 0)

#Iterate through the data and append male like counts to the male dictionary and female like counts
#to the female dictionary
for x in range(len(likeData)):
	if df2.loc[x, 'userid'] in modelDict:
		if modelDict[df2.loc[x, 'userid']] == 1.0:
			likeDictFemale[df2.loc[x, 'like_id']] = likeDictFemale[df2.loc[x, 'like_id']] +1
		else:
			likeDictMale[df2.loc[x, 'like_id']] = likeDictMale[df2.loc[x, 'like_id']] +1

# create answer dictionary (Most likely gender to like a page), if page not liked by
#Any training user, just assign to be a boy
answerDict_Likeid_gender = dict.fromkeys(unique_like_ids, 0)
for f in answerDict_Likeid_gender:
	if likeDictFemale[f] > likeDictMale[f]:
		answerDict_Likeid_gender[f] = 1
	else:
		answerDict_Likeid_gender[f] = 0
with open('SavedModel.pkl.txt', 'wb') as f:
	pickle.dump(answerDict_Likeid_gender, f)
#--------------------------------------------------------------------------
#Determine gender of user (test Model)
#--------------------------------------------------------------------------
dictMale = copy.deepcopy(testDict)
dictFemale = copy.deepcopy(testDict)
finalAnswerDict = copy.deepcopy(testDict)
for x in range(len(likeData)):
	if( df2.loc[x, 'userid'] in testDict):
		if answerDict_Likeid_gender[df2.loc[x, 'like_id']] == 1:
			dictFemale[df2.loc[x, 'userid']] = dictFemale[df2.loc[x, 'userid']] +1
		else:
			dictMale[df2.loc[x, 'userid']] = dictMale[df2.loc[x, 'userid']] + 1

for u in finalAnswerDict:
	if dictFemale[u] > dictMale[u]:
		finalAnswerDict[u] = 1.0
	else:
		finalAnswerDict[u] = 0.0
		
#---------------------------------------------------------------------------
#Determine the accuracy
#---------------------------------------------------------------------------
countCorrect = 0

for d in finalAnswerDict:
	if finalAnswerDict[d] == testDict[d]:
		countCorrect = countCorrect +1
print(countCorrect/len(testDict))
print(len(testDict))