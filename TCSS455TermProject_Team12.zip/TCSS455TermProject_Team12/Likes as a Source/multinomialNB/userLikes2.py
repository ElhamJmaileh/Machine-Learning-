#ML in Python
#Guessing gender and age based on facebook likes technique 2: MultinomialNB()

import numpy as np
import pandas as pd
import xml.etree.ElementTree as ET
import itertools
import copy
import pickle
import sys
import codecs
import os
import argparse
from os.path import basename, exists, join, splitext
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix

#------------------------------------------------------------------------------------
# Here we are testing the model for gender. 
#------------------------------------------------------------------------------------

#Import the saved models
file3 = open("genderlikes.pkl",'rb')
model2 = pickle.load(file3)

file4 = open("genderVectors.pkl",'rb')
cv2 = pickle.load(file4)

#Read the relation csv file
df2 = pd.read_csv(sys.argv[1] + "/relation/relation.csv").astype(str).drop_duplicates()
df2 = df2.sort_values(by='userid', ascending=True).groupby('userid')

df2 = df2.agg({'like_id':lambda x:' '.join(x.astype(str))}).reset_index()
like_ids2 = df2['like_id']

userids2 = df2['userid']
   
vector2 = cv2.transform(like_ids2)

# using the count vector to predict gender
prediction2 = model2.predict(vector2)

# using the ID and gender columns in our dataframe to create a dictionary
results2 = dict(zip(userids2, prediction2))
for x in results2:
    if results2[x] == 1.0:
        results2[x] = 'female'
    else:
        results2[x] = 'male'



#------------------------------------------------------------------------------------
# Here we are testing the model for Age. 
#------------------------------------------------------------------------------------
 
#Import the saved models       
file = open("agelikes.pkl",'rb')
model = pickle.load(file)
# loading the count vectorizer created using test data to keep everything consistent
file2 = open("ageVectors.pkl",'rb')
cv = pickle.load(file2)

#Read the relation csv file
df = pd.read_csv(sys.argv[1] + "/relation/relation.csv").astype(str).drop_duplicates()
df = df.sort_values(by='userid', ascending=True).groupby('userid')

df = df.agg({'like_id':lambda x:' '.join(x.astype(str))}).reset_index()
like_ids = df['like_id']
userids = df['userid']


vector = cv.transform(like_ids)

# using the count vector to predict age
prediction = model.predict(vector)

# using the ID and age columns in our dataframe to create a dictionary
results = dict(zip(userids, prediction))
#return results


	
#create xml files
for ID in results:
    filename = '%s.xml' % ID
    filepath = sys.argv[2]+ filename
	
    data = ET.Element('user')
    data.set('id', ID)
    data.set('age_group', results[ID])
    data.set('gender', results2[ID])
    data.set('extrovert', '3.49')
    data.set('neurotic', '2.73')
    data.set('agreeable', '3.58')
    data.set('conscientious', '3.45')
    data.set('open', '3.91')


    mydata = ET.tostring(data).decode()
    myoutput = open(filepath, 'w+')
    myoutput.write(mydata)
    myoutput.close()






