import os
import sys
import random
import pandas as pd
import numpy as np
import xml.etree.ElementTree as ET
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix

"""
generateDataFrame method to make a dataframe with the
status update and the age of the user of said status
"""
def generateDataFrame(directory, isTrain):
  print('Now generating status update / age dataframe')
  trainingdirectory = directory + 'text/'
  profile_directory = directory + 'profile/profile.csv'
  profile = pd.read_csv(profile_directory)
  data = []
  for filename in os.listdir(trainingdirectory):
    if filename.endswith('.txt'):
      ids = filename.split('.')[0]
      filepath = trainingdirectory + filename
      textfile = open(filepath, 'r', encoding = 'latin-1')
      file_contents = textfile.read()
      if isTrain:
        age = profile.loc[profile['userid'] == ids, 'age']
        age = age.iloc[0]
        if age < 25:
          age = 'xx-24'
        elif age < 35:
          age = '25-34'
        elif age < 50:
          age = '35-49'
        else:
          age = '50-xx'
      else:
        age = '-'
      statusGenderPair = [ids, file_contents, age]
      data.append(statusGenderPair)
      textfile.close()

  return pd.DataFrame(data, columns = ['userid', 'status', 'age'])

"""
learn method to train the model and then test it 
on the testing data
"""
def learn(traindf, testdf):
  # data_test = testdf
  # data_train = traindf
  all_Ids = np.arange(len(traindf)) 
  n = 1500
  random.shuffle(all_Ids)
  test_Ids = all_Ids[0:n]
  train_Ids = all_Ids[n:]
  data_test = traindf.loc[test_Ids, :]
  data_train = traindf

  count_vect = CountVectorizer()
  X_train = count_vect.fit_transform(data_train['status'])
  y_train = data_train['age']
  # clf = LogisticRegression(random_state=0)
  clf = MultinomialNB()
  clf.fit(X_train, y_train)

  X_test = count_vect.transform(data_test['status'])
  y_predicted = clf.predict(X_test)
  y_test = data_test['age']
  return y_predicted, y_test


traindf = generateDataFrame('data/training/', True)
testdf = generateDataFrame(sys.argv[1], False)
lst, _ = learn(traindf, testdf)
res = []

# Run the test 10 times
for i in range(10):
  lst, testlist = learn(traindf, testdf)
  res.append(accuracy_score(testlist,lst))
  print("Accuracy: %.2f" % accuracy_score(testlist,lst))

print(sum(res)/ len(res))

# Generating the xml files
count = 0
for ID in testdf.userid:
  filename = '%s.xml' % ID
  filepath = sys.argv[2] + filename
  data = ET.Element('user')
  data.set('id', ID)
  data.set('age_group', lst[count])
  data.set('gender', str(1))
  data.set('extrovert', '3.49')
  data.set('neurotic', '2.73')
  data.set('agreeable', '3.58')
  data.set('conscientious', '3.45')
  data.set('open', '3.91')

  mydata = ET.tostring(data).decode()
  myoutput = open(filepath, 'w+')
  myoutput.write(mydata)
  myoutput.close()
  count += 1